import React, { useState, useEffect, useRef } from "react";

const Countdown = () => {
  const [time, setTime] = useState(""); 
  const [countdown, setCountdown] = useState(null);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    if (isRunning && !isPaused && countdown > 0) {
      timerRef.current = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    }

    if (countdown === 0) {
      clearInterval(timerRef.current);
      setIsRunning(false);
    }

    return () => clearInterval(timerRef.current);
  }, [isRunning, isPaused, countdown]);

  const handleStartPause = () => {
    if (!isRunning) {
      setCountdown(Number(time));
      setIsRunning(true);
      setIsPaused(false);
    } else if (isPaused) {
      setIsPaused(false);
    } else {
      setIsPaused(true);
    }
  };

  const handleCancel = () => {
    clearInterval(timerRef.current);
    setIsRunning(false);
    setIsPaused(false);
    setCountdown(null);
    setTime("");
  };

  return (
    <div className="page-container">
      <div className="countdown-container">
        <div className="countdown-display">
          Countdown: <span>{countdown !== null ? countdown : "Place for countdown"}</span>
        </div>

        <InputCount time={time} setTime={setTime} />

        <PauseResumeButton isRunning={isRunning} isPaused={isPaused} onClick={handleStartPause} />
        <CancelButton onClick={handleCancel} />
      </div>

      <style>{`
        .page-container {
          display: flex;
          align-items: center;
          justify-content: center;
          height: 100vh;
          background: #eef2f3;
        }

        .countdown-container {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: #f7f7f7;
          padding: 600px;
          border-radius: 12px;
          box-shadow: 0 4px 15px rgba(0,0,0,0.1);
          max-width: 300px;
          width: 100%;
          font-family: Arial, sans-serif;
        }

        .countdown-display {
          font-size: 20px;
          margin-bottom: 15px;
          font-weight: bold;
          

        }

        input {
          padding: 10px;
          margin-bottom: 15px;
          border-radius: 6px;
          border: 1px solid #ccc;
          text-align: center;
          width: 100%;
          font-size: 16px;
        }

        button {
          padding: 10px 20px;
          margin: 5px;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 16px;
          color: white;
          background-color: #007bff;
          transition: background 0.3s;
        }

        button:hover {
          background-color: #0056b3;
        }

        button:last-of-type {
          background-color: #dc3545;
        }

        button:last-of-type:hover {
          background-color: #a71d2a;
        }
      `}</style>
    </div>
  );
};

const InputCount = ({ time, setTime }) => {
  return (
    <input
      placeholder="Please set time"
      type="number"
      min="1"
      max="60"
      value={time}
      onChange={(e) => setTime(e.target.value)}
    />
  );
};

const PauseResumeButton = ({ isRunning, isPaused, onClick }) => {
  let text = "Start";
  if (isRunning && !isPaused) text = "Pause";
  if (isRunning && isPaused) text = "Continue";
  return <button onClick={onClick}>{text}</button>;
};

const CancelButton = ({ onClick }) => {
  return <button onClick={onClick}>Cancel</button>;
};

export default Countdown;
