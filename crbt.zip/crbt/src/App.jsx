// App.jsx
import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Login from "./pages/Login";
import BrowseTones from "./pages/BrowseTones";
import Dashboard from "./pages/Dashboard";

/*
  App holds top-level state: user (mobile number) and activeTone.
  It passes down setters to child components. All data is in-memory and resets on refresh.
*/

export default function App() {
  const [mobile, setMobile] = useState(""); // empty string = not logged in
  const [activeTone, setActiveTone] = useState(null);

  const handleLogout = () => {
    setMobile("");
    setActiveTone(null);
  };

  // basic page container style
  const containerStyle = {
    minHeight: "100vh",
    background:
      "linear-gradient(135deg,#0f172a 0%, #0b1220 100%)",
    paddingBottom: 40,
  };

  return (
    <div style={containerStyle}>
      <Navbar isLoggedIn={!!mobile} onLogout={handleLogout} />
      <Routes>
        <Route path="/" element={<Login setMobile={setMobile} />} />
        <Route
          path="/browse"
          element={
            <BrowseTones
              activeTone={activeTone}
              setActiveTone={setActiveTone}
              mobile={mobile}
            />
          }
        />
        <Route
          path="/dashboard"
          element={<Dashboard mobile={mobile} activeTone={activeTone} />}
        />
        {/* fallback to login */}
        <Route path="*" element={<Login setMobile={setMobile} />} />
      </Routes>
    </div>
  );
}
