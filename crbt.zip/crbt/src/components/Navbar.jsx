// components/Navbar.jsx
import React from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Navbar({ isLoggedIn, onLogout }) {
  const navStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    padding: "14px 20px",
    color: "#e6eef8",
    background: "linear-gradient(90deg,#0b1220,#111827)",
    borderBottom: "1px solid rgba(255,255,255,0.04)",
    boxShadow: "0 4px 14px rgba(2,6,23,0.6)",
  };

  const leftStyle = { display: "flex", alignItems: "center", gap: 16 };
  const brandStyle = { color: "#e6f7ff", fontWeight: 800, fontSize: 18 };
  const rightStyle = { display: "flex", alignItems: "center", gap: 10 };

  const linkStyle = {
    color: "#cfe6ff",
    textDecoration: "none",
    padding: "6px 10px",
    borderRadius: 8,
    transition: "all .15s",
  };

  const navigate = useNavigate();
  const handleLogoutClick = () => {
    onLogout();
    navigate("/");
  };

  return (
    <header style={navStyle}>
      <div style={leftStyle}>
        <div style={brandStyle}>CRBT</div>
        <nav>
          <Link to="/" style={linkStyle}>
            Login
          </Link>
          <Link to="/browse" style={{ ...linkStyle, marginLeft: 8 }}>
            Browse Tones
          </Link>
          <Link to="/dashboard" style={{ ...linkStyle, marginLeft: 8 }}>
            Dashboard
          </Link>
        </nav>
      </div>

      <div style={rightStyle}>
        {isLoggedIn ? (
          <button
            onClick={handleLogoutClick}
            style={{
              background: "linear-gradient(90deg,#ef4444,#f97316)",
              border: "none",
              color: "#04121a",
              padding: "8px 12px",
              borderRadius: 8,
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Logout
          </button>
        ) : (
          <div style={{ color: "#9fb2d9", fontSize: 14 }}>Not logged in</div>
        )}
      </div>
    </header>
  );
}
