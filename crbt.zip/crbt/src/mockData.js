// mockData.js
export const tones = [
  { id: 1, name: "Romantic Melody", category: "Romantic", icon: "🎵" },
  { id: 2, name: "Classic Tune", category: "Classical", icon: "🎼" },
  { id: 3, name: "Hip Hop Beat", category: "Hip Hop", icon: "🎧" },
  { id: 4, name: "Pop Hit", category: "Pop", icon: "🎤" },
  { id: 5, name: "Nature Sounds", category: "Relax", icon: "🌿" },
  { id: 6, name: "Jazz Groove", category: "Jazz", icon: "🎷" }
];
