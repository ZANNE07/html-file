// pages/BrowseTones.jsx
import React from "react";
import { tones } from "../mockData";
import { useNavigate } from "react-router-dom";

export default function BrowseTones({ activeTone, setActiveTone, mobile }) {
  const navigate = useNavigate();

  return (
    <>
      <style>{`
        .container {
          max-width: 980px;
          margin: 28px auto;
          padding: 20px;
          color: #eaf4ff;
        }

        .title {
          margin-bottom: 6px;
        }

        .subtitle {
          color: #cfe6ff;
          margin-top: 0;
        }

        .grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 16px;
          margin-top: 12px;
        }

        .card {
          background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
          border-radius: 12px;
          padding: 16px;
          border: 1px solid rgba(255,255,255,0.06);
          box-shadow: 0 8px 18px rgba(2,6,23,0.5);
          text-align: center;
        }

        .icon {
          font-size: 36px;
        }

        .toneName {
          margin: 8px 0 4px;
        }

        .toneCategory {
          color: #9fb2d9;
          font-size: 13px;
        }

        .btn {
          margin-top: 12px;
          padding: 8px 12px;
          border-radius: 8px;
          border: none;
          font-weight: 700;
          cursor: pointer;
          color: #04111a;
          background: linear-gradient(90deg,#6366f1,#06b6d4);
        }

        .btn.subscribed {
          background: linear-gradient(90deg,#10b981,#34d399);
          color: #052014;
          cursor: default;
        }
      `}</style>

      <div className="container">
        <h2 className="title">Browse Tones</h2>
        <p className="subtitle">
          {mobile ? `Logged in as ${mobile}` : "You can preview and subscribe to tones (login to keep session)."}
        </p>

        <div className="grid">
          {tones.map((tone) => {
            const subscribed = activeTone?.id === tone.id;
            return (
              <div key={tone.id} className="card">
                <div className="icon">{tone.icon}</div>
                <h3 className="toneName">{tone.name}</h3>
                <div className="toneCategory">{tone.category}</div>

                <button
                  className={`btn ${subscribed ? "subscribed" : ""}`}
                  onClick={() => {
                    setActiveTone(tone);
                    // navigate("/dashboard"); // optional
                  }}
                  disabled={subscribed}
                  title={subscribed ? "This is your active tone" : "Click to subscribe"}
                >
                  {subscribed ? "Subscribed" : "Subscribe"}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}
