// pages/Dashboard.jsx
import React from "react";

export default function Dashboard({ mobile, activeTone }) {
  const container = {
    maxWidth: 720,
    margin: "28px auto",
    padding: 20,
    color: "#eaf4ff",
  };

  const panel = {
    background: "linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))",
    borderRadius: 12,
    padding: 18,
    border: "1px solid rgba(255,255,255,0.06)",
    boxShadow: "0 8px 18px rgba(2,6,23,0.5)",
  };

  const small = { color: "#9fb2d9", fontSize: 14 };

  return (
    <div style={container}>
      <h2 style={{ marginBottom: 6 }}>Dashboard</h2>
      <div style={panel}>
        {mobile ? (
          <>
            <div style={{ marginBottom: 8 }}>
              <div style={small}>Logged in mobile</div>
              <div style={{ fontWeight: 800, fontSize: 18 }}>{mobile}</div>
            </div>

            <div>
              <div style={small}>Active Tone</div>
              {activeTone ? (
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 8 }}>
                  <div style={{ fontSize: 36 }}>{activeTone.icon}</div>
                  <div>
                    <div style={{ fontWeight: 700 }}>{activeTone.name}</div>
                    <div style={{ color: "#cfe6ff", fontSize: 13 }}>{activeTone.category}</div>
                  </div>
                </div>
              ) : (
                <div style={{ marginTop: 8, color: "#cfe6ff" }}>No active tone. Visit Browse Tones to subscribe.</div>
              )}
            </div>
          </>
        ) : (
          <div style={{ color: "#cfe6ff" }}>You are not logged in. Please login to see your dashboard.</div>
        )}
      </div>
    </div>
  );
}
