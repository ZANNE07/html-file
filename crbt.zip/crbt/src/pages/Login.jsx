// pages/Login.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login({ setMobile }) {
  const [mobileInput, setMobileInput] = useState("");
  const [err, setErr] = useState("");
  const navigate = useNavigate();

  const cardStyle = {
    maxWidth: 420,
    margin: "36px auto",
    background: "linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))",
    color: "#eaf4ff",
    padding: 24,
    borderRadius: 12,
    boxShadow: "0 10px 30px rgba(2,6,23,0.6)",
  };

  const inputStyle = {
    width: "100%",
    padding: "10px 12px",
    borderRadius: 8,
    border: "1px solid rgba(255,255,255,0.08)",
    background: "rgba(255,255,255,0.02)",
    color: "#eaf4ff",
    marginBottom: 12,
    fontSize: 15,
  };

  const btnStyle = {
    width: "100%",
    padding: "10px",
    borderRadius: 8,
    border: "none",
    background: "linear-gradient(90deg,#6366f1,#06b6d4)",
    color: "#04111a",
    fontWeight: 700,
    cursor: "pointer",
  };

  const handleLogin = () => {
    // No strict validation required per constraints; accept any non-empty input.
    if (!mobileInput.trim()) {
      setErr("Please enter your mobile number.");
      return;
    }
    setErr("");
    setMobile(mobileInput.trim());
    navigate("/dashboard");
  };

  return (
    <div style={{ padding: 20 }}>
      <div style={cardStyle}>
        <h2 style={{ marginTop: 0 }}>Login</h2>
        <p style={{ color: "#cfe6ff", marginTop: 0, marginBottom: 8 }}>
          Enter your mobile number to continue.
        </p>

        <input
          style={inputStyle}
          type="tel"
          placeholder="Mobile number (any number accepted)"
          value={mobileInput}
          onChange={(e) => setMobileInput(e.target.value)}
        />
        {err && <div style={{ color: "#ffb4b4", marginBottom: 8 }}>{err}</div>}

        <button style={btnStyle} onClick={handleLogin}>
          Continue
        </button>
      </div>
    </div>
  );
}
