import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LoginPage from "./components/LoginPage";
import AdminLoginPage from "./components/AdminLoginPage";
import DashboardPage from "./components/DashboardPage";
import Dashboard from "./components/Dashboard";
import RatingSystem from "./components/RatingSystem";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/admin" element={<AdminLoginPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/dashboard-simple" element={<Dashboard />} />

        {/* New Feedback Page Route */}
        <Route path="/feedback" element={<RatingSystem />} />
      </Routes>
    </Router>
  );
}

export default App;
