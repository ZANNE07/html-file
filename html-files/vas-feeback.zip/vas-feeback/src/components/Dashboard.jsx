import React, { useState } from "react";
import "./../styles/Dashboard.css";

const servicesData = [
  { id: 1, title: "Netflix", category: "Entertainment", description: "Streaming service" },
  { id: 2, title: "Amazon", category: "Shopping", description: "E-commerce platform" },
  { id: 3, title: "Spotify", category: "Entertainment", description: "Music streaming service" },
  { id: 4, title: "Flipkart", category: "Shopping", description: "Online shopping site" },
  { id: 5, title: "Swiggy", category: "Food", description: "Food delivery app" },
];

const Dashboard = () => {
  const [search, setSearch] = useState("");
  const [filterCategory, setFilterCategory] = useState("All");

  // 🔍 Filter Logic
  const filteredServices = servicesData.filter((service) => {
    const matchesSearch = service.title.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = filterCategory === "All" || service.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="dashboard">
      <h1>VAS Feedback & Rating Dashboard</h1>

      {/* Search & Filter */}
      <div className="filters">
        <input
          type="text"
          placeholder="Search services..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <div className="categories">
          {["All", "Entertainment", "Shopping", "Food"].map((cat) => (
            <button
              key={cat}
              className={filterCategory === cat ? "active" : ""}
              onClick={() => setFilterCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Services Grid */}
      <div className="services-grid">
        {filteredServices.length > 0 ? (
          filteredServices.map((service) => (
            <div key={service.id} className="service-card">
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <span className="category-tag">{service.category}</span>
            </div>
          ))
        ) : (
          <p className="no-results">No services found!</p>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
