import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./../styles/DashboardPage.css";

const servicesData = [
  { id: 1, title: "Premium Caller Tunes", description: "Set your favorite songs as caller tunes.", category: "Featured Services", reviews: 432, rating: 4.5, icon: "🎵" },
  { id: 2, title: "Unlimited Data Pack", description: "Enjoy unlimited high-speed data.", category: "Featured Services", reviews: 1245, rating: 4.8, icon: "📶" },
  { id: 3, title: "Premium Video Streaming", description: "Access premium movies and shows.", category: "Featured Services", reviews: 876, rating: 4.6, icon: "🎬" },
  { id: 4, title: "Mobile Gaming Pass", description: "100+ premium mobile games without ads.", category: "Entertainment", reviews: 328, rating: 4.4, icon: "🎮" },
  { id: 5, title: "Music Streaming Plus", description: "Stream millions of songs ad-free.", category: "Entertainment", reviews: 952, rating: 5, icon: "🎧" },
  { id: 6, title: "E-Book Library", description: "Access thousands of e-books.", category: "Entertainment", reviews: 512, rating: 4, icon: "📚" },
  { id: 7, title: "Cloud Storage Pro", description: "50GB secure cloud storage.", category: "Utility Services", reviews: 687, rating: 4.3, icon: "☁️" },
  { id: 8, title: "Mobile Security Suite", description: "Protection against viruses and malware.", category: "Utility Services", reviews: 423, rating: 5, icon: "🛡️" },
  { id: 9, title: "International SMS Pack", description: "Send SMS worldwide at reduced rates.", category: "Utility Services", reviews: 215, rating: 3, icon: "✉️" },
];

const categories = ["All Services", "Featured Services", "Entertainment", "Utility Services"];

export default function DashboardPage() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Services");
  const navigate = useNavigate();

  const filteredServices = servicesData.filter((service) => {
    const matchesCategory = selectedCategory === "All Services" || service.category === selectedCategory;
    const matchesSearch = service.title.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="dashboard">
      {/* Navbar */}
      <header className="navbar">
        <h2>VAS Feedback & Ratings</h2>
        <nav>
          <a href="#">Dashboard</a>
          <a href="#">Services</a>
          <a href="#">My Reviews</a>
          <a href="#">Analytics</a>
          <a href="#">Help</a>
        </nav>
        <div className="profile">
          <span>John Doe</span>
          <div className="avatar">JD</div>
        </div>
      </header>

      {/* Search Bar */}
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search for services..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button>🔍</button>
      </div>

      {/* Category Filters */}
      <div className="filters">
        {categories.map((cat) => (
          <button
            key={cat}
            className={selectedCategory === cat ? "active" : ""}
            onClick={() => setSelectedCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Services Grid */}
      <div className="services-grid">
        {filteredServices.length > 0 ? (
          filteredServices.map((service) => (
            <div className="service-card" key={service.id}>
              <div className="icon">{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
              <p>⭐ {service.rating} ({service.reviews} reviews)</p>
              <button
                className="btn"
                onClick={() => navigate("/feedback")}
              >
                Rate & Review
              </button>
            </div>
          ))
        ) : (
          <p>No services found!</p>
        )}
      </div>
    </div>
  );
}
