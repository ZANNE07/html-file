// App.jsx
import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import RequestMNP from "./pages/RequestMNP";
import Admin from "./pages/Admin";

/*
  Top-level App: manages global in-memory state:
  - currentUser: { mobile, operator } or null
  - mnpRequest: null or { mobile, from, to, status } where status = "Pending"|"Completed"
*/

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [mnpRequest, setMnpRequest] = useState(null);

  const handleLogout = () => {
    setCurrentUser(null);
    setMnpRequest(null);
  };

  // Approve request (admin)
  const approveRequest = () => {
    if (!mnpRequest) return;
    // update request status
    setMnpRequest({ ...mnpRequest, status: "Completed" });
    // update user's operator if currentUser matches the request's mobile
    if (currentUser && currentUser.mobile === mnpRequest.mobile) {
      setCurrentUser({ ...currentUser, operator: mnpRequest.to });
    }
  };

  // Submit MNP request
  const submitMnpRequest = (mobile, from, to) => {
    setMnpRequest({ mobile, from, to, status: "Pending" });
  };

  const containerStyle = {
    minHeight: "100vh",
    background: "linear-gradient(135deg,#0b1220,#0f172a)",
    color: "#eaf4ff",
    fontFamily: "Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial",
  };

  return (
    <div style={containerStyle}>
      <Navbar isLoggedIn={!!currentUser} onLogout={handleLogout} />
      <Routes>
        <Route
          path="/"
          element={<Login setCurrentUser={setCurrentUser} />}
        />
        <Route
          path="/dashboard"
          element={
            <Dashboard
              currentUser={currentUser}
              mnpRequest={mnpRequest}
            />
          }
        />
        <Route
          path="/request"
          element={
            <RequestMNP
              currentUser={currentUser}
              submitMnpRequest={submitMnpRequest}
              mnpRequest={mnpRequest}
            />
          }
        />
        <Route
          path="/admin"
          element={
            <Admin
              mnpRequest={mnpRequest}
              approveRequest={approveRequest}
            />
          }
        />
        <Route path="*" element={<Login setCurrentUser={setCurrentUser} />} />
      </Routes>
    </div>
  );
}
