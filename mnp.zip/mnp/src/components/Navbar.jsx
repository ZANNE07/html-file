// components/Navbar.jsx
import React from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Navbar({ isLoggedIn, onLogout }) {
  const navStyle = {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "14px 20px",
    background: "linear-gradient(90deg,#071029,#0b1420)",
    borderBottom: "1px solid rgba(255,255,255,0.04)",
    color: "#eaf4ff",
  };

  const left = { display: "flex", alignItems: "center", gap: 18 };
  const right = { display: "flex", alignItems: "center", gap: 10 };

  const linkStyle = {
    color: "#cfe6ff",
    textDecoration: "none",
    padding: "6px 10px",
    borderRadius: 8,
  };

  const navigate = useNavigate();
  const handleLogout = () => {
    onLogout();
    navigate("/");
  };

  return (
    <header style={navStyle}>
      <div style={left}>
        <div style={{ fontWeight: 800, fontSize: 18 }}>MNP Simulator</div>
        <nav>
          <Link to="/" style={linkStyle}>Login</Link>
          <Link to="/request" style={{ ...linkStyle, marginLeft: 8 }}>Request MNP</Link>
          <Link to="/dashboard" style={{ ...linkStyle, marginLeft: 8 }}>Dashboard</Link>
          <Link to="/admin" style={{ ...linkStyle, marginLeft: 8 }}>Admin</Link>
        </nav>
      </div>

      <div style={right}>
        {isLoggedIn ? (
          <button
            onClick={handleLogout}
            style={{
              background: "linear-gradient(90deg,#ef4444,#f97316)",
              border: "none",
              padding: "8px 12px",
              borderRadius: 8,
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Logout
          </button>
        ) : (
          <div style={{ color: "#9fb2d9" }}>Not logged in</div>
        )}
      </div>
    </header>
  );
}
