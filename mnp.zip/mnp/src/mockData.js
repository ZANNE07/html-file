// mockData.js
// Predefined mock users and operators for the demo
export const mockUsers = [
  { mobile: "9999000001", operator: "Airtel" },
  { mobile: "9999000002", operator: "Jio" },
  { mobile: "9999000003", operator: "VI" },
  { mobile: "9999000004", operator: "BSNL" },
];

export const operators = ["Airtel", "Jio", "VI", "BSNL"];
