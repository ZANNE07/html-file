// pages/Admin.jsx
import React from "react";

/*
  Admin page to view and (optionally) approve the single in-memory request.
  This simulates a simple operator/admin approving the port.
*/

export default function Admin({ mnpRequest, approveRequest }) {
  const container = {
    maxWidth: 720,
    margin: "28px auto",
    padding: 20,
    color: "#eaf4ff",
  };

  const panel = {
    background: "linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))",
    borderRadius: 12,
    padding: 18,
    border: "1px solid rgba(255,255,255,0.06)",
  };

  const btn = {
    marginTop: 12,
    padding: "10px 14px",
    borderRadius: 8,
    border: "none",
    fontWeight: 700,
    background: "linear-gradient(90deg,#10b981,#34d399)",
    color: "#04111a",
    cursor: "pointer",
  };

  return (
    <div style={container}>
      <h2 style={{ marginTop: 0 }}>Admin — MNP Requests</h2>

      <div style={panel}>
        {mnpRequest ? (
          <>
            <div><strong>Mobile:</strong> {mnpRequest.mobile}</div>
            <div><strong>From:</strong> {mnpRequest.from}</div>
            <div><strong>To:</strong> {mnpRequest.to}</div>
            <div><strong>Status:</strong> {mnpRequest.status}</div>

            {mnpRequest.status === "Pending" ? (
              <button style={btn} onClick={approveRequest}>Approve Request</button>
            ) : (
              <div style={{ marginTop: 12, color: "#34d399" }}>Request already completed.</div>
            )}
          </>
        ) : (
          <div style={{ color: "#cfe6ff" }}>No requests at the moment.</div>
        )}
      </div>
    </div>
  );
}
