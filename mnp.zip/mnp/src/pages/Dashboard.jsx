// pages/Dashboard.jsx
import React from "react";

/*
  Dashboard:
  - Shows mobile number and current operator (if logged in)
  - Shows MNP status (No Request / Pending / Completed)
*/

export default function Dashboard({ currentUser, mnpRequest }) {
  const container = {
    maxWidth: 720,
    margin: "28px auto",
    padding: 20,
    color: "#eaf4ff",
  };

  const panel = {
    background: "linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))",
    borderRadius: 12,
    padding: 18,
    border: "1px solid rgba(255,255,255,0.06)",
  };

  const small = { color: "#9fb2d9", fontSize: 14 };

  let statusText = "No Request";
  if (mnpRequest) statusText = mnpRequest.status;

  return (
    <div style={container}>
      <h2 style={{ marginTop: 0 }}>Dashboard</h2>

      <div style={panel}>
        {currentUser ? (
          <>
            <div style={{ marginBottom: 12 }}>
              <div style={small}>Mobile</div>
              <div style={{ fontWeight: 800, fontSize: 18 }}>{currentUser.mobile}</div>
            </div>

            <div style={{ marginBottom: 12 }}>
              <div style={small}>Current Operator</div>
              <div style={{ fontWeight: 800, fontSize: 18 }}>{currentUser.operator}</div>
            </div>

            <div>
              <div style={small}>MNP Status</div>
              <div style={{ marginTop: 8 }}>
                {mnpRequest ? (
                  <div>
                    <div><strong>Request For:</strong> {mnpRequest.to}</div>
                    <div><strong>Status:</strong> {mnpRequest.status}</div>
                    <div style={{ marginTop: 8, color: mnpRequest.status === "Pending" ? "#facc15" : "#34d399" }}>
                      {mnpRequest.status === "Pending" ? "Pending approval..." : "Completed ✅"}
                    </div>
                  </div>
                ) : (
                  <div>No Request</div>
                )}
              </div>
            </div>
          </>
        ) : (
          <div style={{ color: "#cfe6ff" }}>Not logged in. Please login to view details.</div>
        )}
      </div>
    </div>
  );
}
