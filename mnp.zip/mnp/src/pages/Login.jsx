// pages/Login.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { mockUsers } from "../mockData";

/*
  Login:
  - Accepts mobile number (any string accepted per constraints)
  - If mobile exists in mockUsers, prefill operator; otherwise default operator "Unknown".
  - On login: set current user and redirect to /dashboard
*/

export default function Login({ setCurrentUser }) {
  const [mobile, setMobile] = useState("");
  const [err, setErr] = useState("");
  const navigate = useNavigate();

  const card = {
    maxWidth: 520,
    margin: "36px auto",
    padding: 24,
    borderRadius: 12,
    background: "linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))",
    boxShadow: "0 10px 30px rgba(2,6,23,0.6)",
    color: "#eaf4ff",
  };

  const input = {
    width: "100%",
    padding: "10px 12px",
    borderRadius: 8,
    border: "1px solid rgba(255,255,255,0.06)",
    background: "rgba(255,255,255,0.02)",
    color: "#eaf4ff",
    marginBottom: 12,
  };

  const btn = {
    width: "100%",
    padding: 10,
    borderRadius: 8,
    border: "none",
    fontWeight: 700,
    background: "linear-gradient(90deg,#6366f1,#06b6d4)",
    color: "#04111a",
    cursor: "pointer",
  };

  const handleLogin = () => {
    if (!mobile.trim()) {
      setErr("Please enter a mobile number.");
      return;
    }
    setErr("");
    // check mockUsers for operator
    const found = mockUsers.find((u) => u.mobile === mobile.trim());
    const operator = found ? found.operator : "Unknown";
    setCurrentUser({ mobile: mobile.trim(), operator });
    navigate("/dashboard");
  };

  return (
    <div style={{ padding: 20 }}>
      <div style={card}>
        <h2 style={{ marginTop: 0 }}>Login</h2>
        <p style={{ color: "#cfe6ff", marginTop: 0 }}>Enter your mobile number to continue (no OTP required).</p>

        <input
          type="text"
          placeholder="Mobile number"
          value={mobile}
          onChange={(e) => setMobile(e.target.value)}
          style={input}
        />
        {err && <div style={{ color: "#ffb4b4", marginBottom: 10 }}>{err}</div>}

        <button style={btn} onClick={handleLogin}>Continue</button>
      </div>
    </div>
  );
}
