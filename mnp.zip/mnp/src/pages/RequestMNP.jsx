// pages/RequestMNP.jsx
import React, { useState } from "react";
import { operators } from "../mockData";
import { useNavigate } from "react-router-dom";

/*
  RequestMNP:
  - shows current operator (if logged in)
  - allows selecting a new operator (cannot be same as current)
  - on submit, calls submitMnpRequest(mobile, from, to)
*/

export default function RequestMNP({ currentUser, submitMnpRequest, mnpRequest }) {
  const [selected, setSelected] = useState("");
  const [msg, setMsg] = useState("");
  const navigate = useNavigate();

  const wrapper = {
    maxWidth: 720,
    margin: "28px auto",
    padding: 20,
    color: "#eaf4ff",
  };

  const panel = {
    background: "linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))",
    padding: 16,
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.06)",
  };

  const selectStyle = {
    width: "100%",
    padding: 10,
    borderRadius: 8,
    border: "1px solid rgba(255,255,255,0.06)",
    background: "rgba(255,255,255,0.02)",
    color: "rgba(32, 2, 2, 1)",
    fontSize: 14,
  };

  const btn = {
    marginTop: 12,
    padding: "10px 14px",
    borderRadius: 8,
    border: "none",
    fontWeight: 700,
    background: "linear-gradient(90deg,#6366f1,#06b6d4)",
    color: "#04111a",
    cursor: "pointer",
  };

  const handleSubmit = () => {
    if (!currentUser) {
      setMsg("Please login first.");
      return;
    }
    if (!selected) {
      setMsg("Please select the operator you want to port to.");
      return;
    }
    if (selected === currentUser.operator) {
      setMsg("Selected operator is same as your current operator.");
      return;
    }
    // submit request
    submitMnpRequest(currentUser.mobile, currentUser.operator, selected);
    setMsg("MNP request submitted and is now Pending.");
    // navigate to dashboard
    navigate("/dashboard");
  };

  return (
    <div style={wrapper}>
      <h2 style={{ marginTop: 0 }}>Request Mobile Number Portability (MNP)</h2>

      <div style={panel}>
        <div style={{ marginBottom: 12 }}>
          <div style={{ color: "#9fb2d9", fontSize: 14 }}>Current Operator</div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>{currentUser ? currentUser.operator : "Not logged in"}</div>
        </div>

        <div style={{ marginTop: 6 }}>
          <label style={{ display: "block", marginBottom: 8, color: "#cfe6ff" }}>Select New Operator</label>
          <select style={selectStyle} value={selected} onChange={(e) => setSelected(e.target.value)}>
            <option value="">-- choose operator --</option>
            {operators.map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>

          <button style={btn} onClick={handleSubmit}>Submit MNP Request</button>

          {msg && <div style={{ marginTop: 10, color: "#cfe6ff" }}>{msg}</div>}
          {mnpRequest && mnpRequest.status === "Pending" && (
            <div style={{ marginTop: 10, color: "#facc15" }}>You have a pending request for {mnpRequest.to}.</div>
          )}
        </div>
      </div>
    </div>
  );
}
