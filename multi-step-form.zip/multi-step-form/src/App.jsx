import React, { useState } from "react";

export default function ServiceOutageForm() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    issue: "",
    location: "",
    files: []
  });
  const [uploadProgress, setUploadProgress] = useState({});
  const [errors, setErrors] = useState({});

  // Handle text field changes
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle file selection
  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setFormData({ ...formData, files });
  };

  // Simulate file upload
  const simulateUpload = () => {
    const newProgress = {};
    formData.files.forEach((file) => {
      newProgress[file.name] = 0;
    });
    setUploadProgress(newProgress);

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        const updated = { ...prev };
        let completed = true;
        for (let file in updated) {
          if (updated[file] < 100) {
            updated[file] += 20;
            completed = false;
          }
        }
        if (completed) clearInterval(interval);
        return updated;
      });
    }, 500);
  };

  // Validation
  const validateStep = () => {
    let newErrors = {};
    if (step === 1 && !formData.issue) newErrors.issue = "Issue description is required";
    if (step === 2 && !formData.location) newErrors.location = "Location details are required";
    if (step === 3 && formData.files.length === 0) newErrors.files = "At least one file is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Next Step
  const handleNext = () => {
    if (validateStep()) {
      if (step === 3) simulateUpload();
      setStep(step + 1);
    }
  };

  // Back Step
  const handleBack = () => setStep(step - 1);

  // Submit and Reset
  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Service outage report submitted successfully!");
    console.log("Submitted Data:", formData);

    // Reset form after submission
    setFormData({ issue: "", location: "", files: [] });
    setUploadProgress({});
    setErrors({});
    setStep(1); // Go back to first step
  };

  return (
    <div className="form-wrapper">
      <div className="form-container">
        <h2>Report Service Outage</h2>

        {step === 1 && (
          <div className="step">
            <label>Describe the Issue:</label>
            <textarea
              name="issue"
              value={formData.issue}
              onChange={handleChange}
              placeholder="Describe the problem..."
            />
            {errors.issue && <p className="error">{errors.issue}</p>}
          </div>
        )}

        {step === 2 && (
          <div className="step">
            <label>Location Details:</label>
            <input
              type="text"
              name="location"
              value={formData.location}
              onChange={handleChange}
              placeholder="Enter location..."
            />
            {errors.location && <p className="error">{errors.location}</p>}
          </div>
        )}

        {step === 3 && (
          <div className="step">
            <label>Attach Files:</label>
            <input type="file" multiple onChange={handleFileChange} />
            {errors.files && <p className="error">{errors.files}</p>}
            {formData.files.map((file) => (
              <div key={file.name} className="progress-container">
                <span>{file.name}</span>
                <progress value={uploadProgress[file.name] || 0} max="100" />
              </div>
            ))}
          </div>
        )}

        {step === 4 && (
          <div className="step">
            <h3>Review Your Submission</h3>
            <p><strong>Issue:</strong> {formData.issue}</p>
            <p><strong>Location:</strong> {formData.location}</p>
            <p><strong>Files:</strong> {formData.files.map(f => f.name).join(", ")}</p>
          </div>
        )}

        <div className="buttons">
          {step > 1 && <button onClick={handleBack}>Back</button>}
          {step < 4 && <button onClick={handleNext}>Next</button>}
          {step === 4 && <button onClick={handleSubmit}>Submit</button>}
        </div>
      </div>

      <style>{`
        .form-wrapper {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
          background: #f4f6f9;
        }
        .form-container {
          max-width: 400px;
          width: 100%;
          padding: 600px;
          border-radius: 10px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.1);
          background: #fff;
          font-family: Arial, sans-serif;
        }
        .step { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, textarea {
          width: 100%;
          padding: 8px;
          margin-bottom: 10px;
          border: 1px solid #ccc;
          border-radius: 6px;
        }
        textarea { min-height: 100px; }
        .error { color: red; font-size: 13px; }
        .buttons { display: flex; justify-content: space-between; }
        button {
          padding: 8px 15px;
          border: none;
          background: #007bff;
          color: #fff;
          border-radius: 6px;
          cursor: pointer;
        }
        button:hover { background: #0056b3; }
        .progress-container {
          margin: 5px 0;
          display: flex;
          flex-direction: row;
        }
        progress { width: 100%; height: 10px; }
      `}</style>
    </div>
  );
}
