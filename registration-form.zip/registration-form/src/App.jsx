import React, { useState } from "react";

export default function RegistrationForm() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    gender: "",
    country: "",
    terms: false,
  });

  const [errors, setErrors] = useState({});
  const [submittedData, setSubmittedData] = useState(null);

  // ✅ Validation logic
  const validate = () => {
    const newErrors = {};
    if (!formData.fullName || formData.fullName.length < 3)
      newErrors.fullName = "Full Name must be at least 3 characters";
    if (!formData.email || !/\S+@\S+\.\S+/.test(formData.email))
      newErrors.email = "Email is not valid";
    if (!formData.password || formData.password.length < 6)
      newErrors.password = "Password must be at least 6 characters";
    if (formData.confirmPassword !== formData.password)
      newErrors.confirmPassword = "Passwords do not match";
    if (!formData.gender) newErrors.gender = "Please select your gender";
    if (!formData.country) newErrors.country = "Please select a country";
    if (!formData.terms) newErrors.terms = "You must agree to Terms & Conditions";
    return newErrors;
  };

  // ✅ Handle input change
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  // ✅ Form Submit
  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmittedData(formData);
    }
  };

  // ✅ Check if form is valid
  const isFormValid = Object.keys(validate()).length === 0;

  return (
    <div style={styles.container}>
      <h2>Registration Form</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        {/* Full Name */}
        <input
          type="text"
          name="fullName"
          placeholder="Full Name"
          value={formData.fullName}
          onChange={handleChange}
          style={styles.input}
        />
        {errors.fullName && <p style={styles.error}>{errors.fullName}</p>}

        {/* Email */}
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
          style={styles.input}
        />
        {errors.email && <p style={styles.error}>{errors.email}</p>}

        {/* Password */}
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          style={styles.input}
        />
        {errors.password && <p style={styles.error}>{errors.password}</p>}

        {/* Confirm Password */}
        <input
          type="password"
          name="confirmPassword"
          placeholder="Confirm Password"
          value={formData.confirmPassword}
          onChange={handleChange}
          style={styles.input}
        />
        {errors.confirmPassword && <p style={styles.error}>{errors.confirmPassword}</p>}

        {/* Gender */}
        <div style={styles.genderContainer}>
          <label>
            <input
              type="radio"
              name="gender"
              value="Male"
              checked={formData.gender === "Male"}
              onChange={handleChange}
            />
            Male
          </label>
          <label>
            <input
              type="radio"
              name="gender"
              value="Female"
              checked={formData.gender === "Female"}
              onChange={handleChange}
            />
            Female
          </label>
          <label>
            <input
              type="radio"
              name="gender"
              value="Other"
              checked={formData.gender === "Other"}
              onChange={handleChange}
            />
            Other
          </label>
        </div>
        {errors.gender && <p style={styles.error}>{errors.gender}</p>}

        {/* Country Dropdown */}
        <select
          name="country"
          value={formData.country}
          onChange={handleChange}
          style={styles.input}
        >
          <option value="">Select Country</option>
          <option value="India">India</option>
          <option value="USA">USA</option>
          <option value="UK">UK</option>
          <option value="Canada">Canada</option>
          <option value="Australia">Australia</option>
        </select>
        {errors.country && <p style={styles.error}>{errors.country}</p>}

        {/* Terms & Conditions */}
        <label style={styles.checkboxLabel}>
          <input
            type="checkbox"
            name="terms"
            checked={formData.terms}
            onChange={handleChange}
          />
          I agree to Terms & Conditions
        </label>
        {errors.terms && <p style={styles.error}>{errors.terms}</p>}

        {/* Submit Button */}
        <button type="submit" style={styles.button} disabled={!isFormValid}>
          Register
        </button>
      </form>

      {/* Success Message */}
      {submittedData && (
        <div style={styles.successBox}>
          <h3>Registration Successful!</h3>
          <p><strong>Full Name:</strong> {submittedData.fullName}</p>
          <p><strong>Email:</strong> {submittedData.email}</p>
          <p><strong>Gender:</strong> {submittedData.gender}</p>
          <p><strong>Country:</strong> {submittedData.country}</p>
        </div>
      )}
    </div>
  );
}

// ✅ CSS Styles
const styles = {
  container: {
    maxWidth: "600px",
    margin: "20px auto",
    padding: "600px",
    background: "#fff",
    borderRadius: "10px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
    textAlign: "center",
    fontFamily: "Arial, sans-serif",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  input: {
    padding: "10px",
    fontSize: "16px",
    borderRadius: "5px",
    border: "1px solid #ccc",
    outline: "none",
  },
  genderContainer: {
    display: "flex",
    justifyContent: "space-around",
    marginTop: "10px",
  },
  checkboxLabel: {
    marginTop: "10px",
    fontSize: "14px",
  },
  button: {
    padding: "10px",
    marginTop: "10px",
    fontSize: "16px",
    border: "none",
    borderRadius: "5px",
    background: "#4CAF50",
    color: "#fff",
    cursor: "pointer",
  },
  error: {
    color: "red",
    fontSize: "12px",
    margin: 0,
  },
  successBox: {
    marginTop: "20px",
    padding: "10px",
    background: "#e8f5e9",
    borderRadius: "8px",
    border: "1px solid #4CAF50",
  },
};
