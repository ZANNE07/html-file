import React, { useState } from "react";

export default function App() {
  const initialForm = {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    phone: "",
    dob: "",
    gender: "",
    country: "",
    plan: "",
    interests: [],
    about: "",
    newsletter: true,
    terms: false
  };

  const [form, setForm] = useState(initialForm);
  const [touched, setTouched] = useState({});
  const [submitted, setSubmitted] = useState(false);

  // ✅ Validation function
  const validate = () => {
    const errors = {};
    if (!form.firstName.trim()) errors.firstName = "First name is required";
    if (!form.lastName.trim()) errors.lastName = "Last name is required";
    if (!form.email) errors.email = "Email is required";
    else if (!/^\S+@\S+\.\S+$/.test(form.email))
      errors.email = "Enter a valid email";
    if (!form.password) errors.password = "Password is required";
    else if (form.password.length < 6)
      errors.password = "Minimum 6 characters required";
    if (!form.phone) errors.phone = "Phone is required";
    else if (!/^\d{10}$/.test(form.phone))
      errors.phone = "Phone must be 10 digits";
    if (!form.dob) errors.dob = "Date of birth is required";
    if (!form.gender) errors.gender = "Gender is required";
    if (!form.country) errors.country = "Country is required";
    if (!form.plan) errors.plan = "Plan selection is required";
    if (!form.terms) errors.terms = "You must accept terms & conditions";
    return errors;
  };

  const errors = validate();
  const isValid = Object.keys(errors).length === 0;

  // ✅ Handle input changes
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (type === "checkbox" && name === "interests") {
      const updated = form.interests.includes(value)
        ? form.interests.filter((i) => i !== value)
        : [...form.interests, value];
      setForm({ ...form, interests: updated });
    } else if (type === "checkbox") {
      setForm({ ...form, [name]: checked });
    } else {
      setForm({ ...form, [name]: value });
    }
  };

  // ✅ Handle blur for inline errors
  const handleBlur = (e) => {
    setTouched({ ...touched, [e.target.name]: true });
  };

  // ✅ Submit handler
  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    if (isValid) {
      alert("Registration successful!");
      console.log("Form Data:", form);
    }
  };

  // ✅ Reset handler
  const handleReset = () => {
    setForm(initialForm);
    setTouched({});
    setSubmitted(false);
  };

  // Helper to show errors only after blur or submit
  const showError = (field) => (touched[field] || submitted) && errors[field];

  // ✅ Fixed styles for better layout
  const styles = {
    container: {
      display: "flex",
      flexWrap: "wrap",
      padding: "20px",
      gap: "20px",
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f9f9f9",
      minHeight: "100vh"
    },
    form: {
      flex: "2",
      minWidth: "1000px",
      maxWidth: "600px",
      background: "white",
      padding: "20px",
      borderRadius: "8px",
      boxShadow: "0 2px 6px rgba(0,0,0,0.1)"
    },
    field: { marginBottom: "15px", display: "flex", flexDirection: "column" },
    label: { marginBottom: "5px", fontWeight: "bold" },
    input: {
      padding: "8px",
      borderRadius: "4px",
      border: "1px solid #ccc"
    },
    error: { color: "red", fontSize: "0.9em", marginTop: "4px" },
    buttons: { marginTop: "10px", display: "flex", gap: "10px" },
    button: {
      padding: "8px 12px",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer"
    },
    submitBtn: {
      background: "#007BFF",
      color: "white"
    },
    resetBtn: {
      background: "#6c757d",
      color: "white"
    },
    jsonPanel: {
      flex: "1",
      minWidth: "365px",
      background: "white",
      padding: "20px",
      borderRadius: "8px",
      boxShadow: "0 2px 6px rgba(0,0,0,0.1)"
    }
  };

  return (
    <div style={styles.container}>
      <form onSubmit={handleSubmit} style={styles.form}>
        <h2>PulseTel Registration</h2>

        {/* Basic Fields */}
        {[
          { label: "First Name", name: "firstName" },
          { label: "Last Name", name: "lastName" },
          { label: "Email", name: "email" },
          { label: "Password", name: "password", type: "password" },
          { label: "Phone", name: "phone" },
          { label: "Date of Birth", name: "dob", type: "date" }
        ].map((f) => (
          <div style={styles.field} key={f.name}>
            <label style={styles.label} htmlFor={f.name}>
              {f.label}:
            </label>
            <input
              id={f.name}
              name={f.name}
              type={f.type || "text"}
              value={form[f.name]}
              onChange={handleChange}
              onBlur={handleBlur}
              style={styles.input}
            />
            {showError(f.name) && <div style={styles.error}>{errors[f.name]}</div>}
          </div>
        ))}

        {/* Gender */}
        <div style={styles.field}>
          <label style={styles.label}>Gender:</label>
          {["Female", "Male", "Other"].map((g) => (
            <label key={g}>
              <input
                type="radio"
                name="gender"
                value={g}
                checked={form.gender === g}
                onChange={handleChange}
                onBlur={handleBlur}
              />{" "}
              {g}
            </label>
          ))}
          {showError("gender") && <div style={styles.error}>{errors.gender}</div>}
        </div>

        {/* Country */}
        <div style={styles.field}>
          <label style={styles.label} htmlFor="country">Country:</label>
          <select
            id="country"
            name="country"
            value={form.country}
            onChange={handleChange}
            onBlur={handleBlur}
            style={styles.input}
          >
            <option value="">Select</option>
            {["India", "United States", "United Kingdom", "Germany", "Australia"].map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          {showError("country") && <div style={styles.error}>{errors.country}</div>}
        </div>

        {/* Plan */}
        <div style={styles.field}>
          <label style={styles.label} htmlFor="plan">Plan:</label>
          <select
            id="plan"
            name="plan"
            value={form.plan}
            onChange={handleChange}
            onBlur={handleBlur}
            style={styles.input}
          >
            <option value="">Select</option>
            {["Basic", "Standard", "Premium"].map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
          {showError("plan") && <div style={styles.error}>{errors.plan}</div>}
        </div>

        {/* Interests */}
        <div style={styles.field}>
          <label style={styles.label}>Interests:</label>
          {["Sports", "Music", "Travel", "Tech", "Movies"].map((i) => (
            <label key={i}>
              <input
                type="checkbox"
                name="interests"
                value={i}
                checked={form.interests.includes(i)}
                onChange={handleChange}
              />{" "}
              {i}
            </label>
          ))}
        </div>

        {/* About */}
        <div style={styles.field}>
          <label style={styles.label} htmlFor="about">About You:</label>
          <textarea
            id="about"
            name="about"
            value={form.about}
            onChange={handleChange}
            style={styles.input}
          />
        </div>

        {/* Newsletter */}
        <div style={styles.field}>
          <label>
            <input
              type="checkbox"
              name="newsletter"
              checked={form.newsletter}
              onChange={handleChange}
            />{" "}
            Subscribe to Newsletter
          </label>
        </div>

        {/* Terms */}
        <div style={styles.field}>
          <label>
            <input
              type="checkbox"
              name="terms"
              checked={form.terms}
              onChange={handleChange}
              onBlur={handleBlur}
            />{" "}
            I accept Terms & Conditions
          </label>
          {showError("terms") && <div style={styles.error}>{errors.terms}</div>}
        </div>

        {/* Buttons */}
        <div style={styles.buttons}>
          <button
            type="submit"
            disabled={!isValid}
            style={{ ...styles.button, ...styles.submitBtn }}
          >
            Submit
          </button>
          <button
            type="button"
            onClick={handleReset}
            style={{ ...styles.button, ...styles.resetBtn }}
          >
            Reset
          </button>
        </div>
      </form>

      {/* Live JSON State */}
      <div style={styles.jsonPanel}>
        <h3>Live State (JSON)</h3>
        <pre>{JSON.stringify(form, null, 2)}</pre>
      </div>
    </div>
  );
}
