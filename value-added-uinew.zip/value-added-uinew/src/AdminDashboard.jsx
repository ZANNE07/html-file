// AdminDashboard.jsx
import { Bell, Download } from "lucide-react";

export default function AdminDashboard({ onLogout }) {
  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold">Admin Dashboard</h2>
        <div className="flex items-center gap-4">
          {/* Notifications */}
          <Bell className="text-gray-600 cursor-pointer" />
          <button
            onClick={onLogout}
            className="px-4 py-2 bg-red-600 text-white rounded-lg"
          >
            Logout
          </button>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Feedback Count */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-semibold">Today's Feedback</h3>
          <p className="text-2xl font-bold text-blue-600 mt-2">45</p>
        </div>

        {/* Highly Rated Orders */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-semibold">Highly Rated Orders</h3>
          <select className="w-full mt-3 border rounded-lg px-3 py-2">
            <option>Order #101 - 5⭐</option>
            <option>Order #102 - 4.8⭐</option>
            <option>Order #103 - 4.7⭐</option>
          </select>
        </div>

        {/* Reports */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-semibold">Reports</h3>
          <button className="flex items-center gap-2 px-4 py-2 mt-3 bg-blue-600 text-white rounded-lg">
            <Download size={18} /> Download Report
          </button>
        </div>
      </div>

      {/* Timeline */}
      <div className="mt-8 bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Timeline</h3>
        <ul className="space-y-2 text-gray-600">
          <li>✔️ Feedback analysis updated</li>
          <li>📌 Order #101 marked as highly rated</li>
          <li>📊 New report generated</li>
        </ul>
      </div>

      {/* Service Word Count Chart */}
      <div className="mt-8 bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Service Word Count</h3>
        <p className="text-gray-500">[Chart will go here]</p>
      </div>
    </div>
  );
}
