import { useState } from "react";
import { Search, Star, Users, MessageSquare } from "lucide-react";
import AdminDashboard from "./AdminDashboard"; // ✅ Import external AdminDashboard

// ✅ Login Modal Component (still inside App for now)
function LoginModal({ onClose, onLogin }) {
  const [role, setRole] = useState("user"); // user | admin
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    // Hardcoded credentials
    if (role === "admin" && email === "admin@example.com" && password === "admin123") {
      onLogin({ role, email });
      onClose();
    } else if (role === "user" && email === "user@example.com" && password === "user123") {
      onLogin({ role, email });
      onClose();
    } else {
      setError("Invalid credentials");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl shadow-lg w-96 p-6 relative">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-2 right-3 text-gray-500 hover:text-gray-800"
        >
          ✖
        </button>

        <h2 className="text-xl font-bold text-center mb-4">
          Choose Account Type
        </h2>

        {/* Account Type Selection */}
        <div className="flex justify-around mb-6">
          <div
            onClick={() => setRole("user")}
            className={`flex flex-col items-center cursor-pointer p-3 rounded-lg border ${
              role === "user" ? "border-blue-600 bg-blue-50" : "border-gray-300"
            }`}
          >
            <img src="/user.jpg" alt="User" className="h-12 w-12 mb-2" />
            <span className="text-sm font-medium">User</span>
          </div>
          <div
            onClick={() => setRole("admin")}
            className={`flex flex-col items-center cursor-pointer p-3 rounded-lg border ${
              role === "admin" ? "border-blue-600 bg-blue-50" : "border-gray-300"
            }`}
          >
            <img src="/admin.jpg" alt="Admin" className="h-12 w-12 mb-2" />
            <span className="text-sm font-medium">Admin</span>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="Email or Phone"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
          <div className="relative">
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
            <div className="flex justify-end mt-2">
              <a href="#" className="text-sm text-blue-600 hover:underline">
                Forgot?
              </a>
            </div>
          </div>

          {error && <p className="text-red-600 text-sm">{error}</p>}

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition"
          >
            Login
          </button>
        </form>

        {/* Signup link */}
        <p className="text-sm text-center mt-4 text-gray-600">
          No account?{" "}
          <a href="#" className="text-blue-600 hover:underline">
            Signup
          </a>
        </p>
      </div>
    </div>
  );
}

// ✅ Services Data
const services = [
  {
    id: 1,
    category: "Data Services",
    title: "Premium Data Plans",
    description:
      "High-speed internet packages with unlimited data for seamless connectivity.",
    rating: 4.5,
    ratingsCount: 234,
    reviewsCount: 89,
  },
  {
    id: 2,
    category: "Financial Services",
    title: "Mobile Banking Plus",
    description:
      "Advanced mobile banking with enhanced security features and instant transactions.",
    rating: 4.8,
    ratingsCount: 456,
    reviewsCount: 178,
  },
  {
    id: 3,
    category: "Cloud Services",
    title: "Cloud Storage Pro",
    description:
      "Secure cloud storage solution with advanced collaboration tools and backup features.",
    rating: 4.3,
    ratingsCount: 189,
    reviewsCount: 67,
  },
  {
    id: 4,
    category: "Security Services",
    title: "Smart Home Security",
    description:
      "Comprehensive home security system with smart monitoring and instant alerts.",
    rating: 4.6,
    ratingsCount: 312,
    reviewsCount: 124,
  },
];

// ✅ Main App
export default function App() {
  const [filter, setFilter] = useState("All");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [role, setRole] = useState(null);
  const [showLogin, setShowLogin] = useState(false);

  const categories = [
    "All",
    "Data Services",
    "Financial Services",
    "Cloud Services",
    "Security Services",
  ];

  const filteredServices =
    filter === "All" ? services : services.filter((s) => s.category === filter);

  const handleLogout = () => {
    setIsLoggedIn(false);
    setRole(null);
  };

  if (isLoggedIn && role === "admin") {
    return <AdminDashboard onLogout={handleLogout} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header with Logo, Title, and Login */}
      <div className="flex justify-between items-center p-6 bg-white shadow">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <img
            src="/logo.jpg" // replace with your logo
            alt="Logo"
            className="h-14 w-14 object-contain"
          />
        </div>

        {/* Title */}
        <h1 className="text-2xl font-bold text-center flex-1">
          Value Added Services
        </h1>

        {/* Login Button */}
        {!isLoggedIn ? (
          <button
            onClick={() => setShowLogin(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg"
          >
            Login
          </button>
        ) : (
          <button
            onClick={handleLogout}
            className="px-4 py-2 bg-red-600 text-white rounded-lg"
          >
            Logout
          </button>
        )}
      </div>

      {/* Search */}
      <div className="flex justify-center mt-6">
        <div className="relative w-full max-w-lg">
          <input
            type="text"
            placeholder="Search services..."
            className="w-full px-4 py-2 pl-10 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
        </div>
      </div>

      {/* Filters */}
      <div className="flex justify-center mt-6 gap-2 flex-wrap">
        {categories.map((c) => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={`px-4 py-1 rounded-full border text-sm ${
              filter === c ? "bg-black text-white" : "bg-white text-gray-700"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {/* Services */}
      <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-8 px-6">
        {filteredServices.map((service) => (
          <div
            key={service.id}
            className="bg-white shadow rounded-xl p-5 border"
          >
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs text-gray-600 font-medium">
                {service.category}
              </span>
              <span className="flex items-center text-yellow-500 font-semibold">
                <Star size={16} className="mr-1" /> {service.rating}
              </span>
            </div>
            <h2 className="text-lg font-semibold">{service.title}</h2>
            <p className="text-sm text-gray-600 mt-2">{service.description}</p>
            <div className="flex items-center gap-4 text-sm text-gray-500 mt-4">
              <span className="flex items-center gap-1">
                <Users size={16} /> {service.ratingsCount} ratings
              </span>
              <span className="flex items-center gap-1">
                <MessageSquare size={16} /> {service.reviewsCount} reviews
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Stats */}
      <div className="bg-white shadow mt-10 rounded-xl p-8 flex justify-around text-center max-w-4xl mx-auto">
        <div>
          <h3 className="text-2xl font-bold">1191</h3>
          <p className="text-gray-500">Total Ratings</p>
        </div>
        <div>
          <h3 className="text-2xl font-bold">458</h3>
          <p className="text-gray-500">Customer Reviews</p>
        </div>
        <div>
          <h3 className="text-2xl font-bold">4.6</h3>
          <p className="text-gray-500">Average Rating</p>
        </div>
      </div>

      {/* ✅ Show Login Modal */}
      {showLogin && (
        <LoginModal
          onClose={() => setShowLogin(false)}
          onLogin={({ role, email }) => {
            setIsLoggedIn(true);
            setRole(role);
            console.log("Logged in as", role, email);
          }}
        />
      )}
    </div>
  );
}
