import { useState } from "react";

export default function LoginModal({ onClose, onLogin }) {
  const [role, setRole] = useState("user");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Hardcoded credentials
    const adminCreds = { email: "admin@example.com", password: "admin123" };
    const userCreds = { email: "user@example.com", password: "user123" };

    if (
      role === "admin" &&
      email === adminCreds.email &&
      password === adminCreds.password
    ) {
      if (remember) localStorage.setItem("rememberMe", "true");
      onLogin({ role: "admin", email });
      onClose();
    } else if (
      role === "user" &&
      email === userCreds.email &&
      password === userCreds.password
    ) {
      if (remember) localStorage.setItem("rememberMe", "true");
      onLogin({ role: "user", email });
      onClose();
    } else {
      alert("Invalid credentials. Please try again.");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl shadow-lg w-96 p-6 relative">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-2 right-3 text-gray-500 hover:text-gray-800"
        >
          ✖
        </button>

        <h2 className="text-xl font-bold text-center mb-4">
          Choose Account Type
        </h2>

        {/* Role Selector */}
        <div className="flex justify-around mb-6">
          <div
            onClick={() => setRole("user")}
            className={`flex flex-col items-center cursor-pointer p-3 rounded-lg border ${
              role === "user"
                ? "border-blue-600 bg-blue-50"
                : "border-gray-300"
            }`}
          >
            <img src="/user.png" alt="User" className="h-12 w-12 mb-2" />
            <span className="text-sm font-medium">User</span>
          </div>
          <div
            onClick={() => setRole("admin")}
            className={`flex flex-col items-center cursor-pointer p-3 rounded-lg border ${
              role === "admin"
                ? "border-blue-600 bg-blue-50"
                : "border-gray-300"
            }`}
          >
            <img src="/admin.png" alt="Admin" className="h-12 w-12 mb-2" />
            <span className="text-sm font-medium">Admin</span>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="Email or Phone"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
          <div className="relative">
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
            <a
              href="#"
              className="absolute right-3 top-2 text-sm text-blue-600 hover:underline"
            >
              Forgot?
            </a>
          </div>

          {/* Remember Me */}
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <input
              type="checkbox"
              checked={remember}
              onChange={() => setRemember(!remember)}
              className="h-4 w-4"
            />
            <span>Remember Me</span>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition"
          >
            Login
          </button>
        </form>

        {/* Signup link */}
        <p className="text-sm text-center mt-4 text-gray-600">
          No account?{" "}
          <a href="#" className="text-blue-600 hover:underline">
            Signup
          </a>
        </p>
      </div>
    </div>
  );
}
