import React from "react";
import "./../styles/AdminLoginPage.css";

const AdminLoginPage = () => {
  return (
    <div className="admin-login-container">
      <div className="login-card">
        {/* Icon */}
        <div className="icon-wrapper">
          <div className="icon-shield">🛡️</div>
        </div>

        {/* Title */}
        <h2>Admin Portal</h2>
        <p className="subtitle">VAS Feedback and Rating System</p>

        {/* Form */}
        <form>
          <label>Username or Email</label>
          <div className="input-wrapper">
            <span className="icon">👤</span>
            <input type="text" placeholder="Enter your username or email" />
          </div>

          <label>Password</label>
          <div className="input-wrapper">
            <span className="icon">🔒</span>
            <input type="password" placeholder="Enter your password" />
          </div>

          <div className="form-options">
            <label>
              <input type="checkbox" /> Remember me
            </label>
          </div>

          <button type="submit" className="btn">
            Login to Admin Dashboard
          </button>
        </form>

        {/* Footer Links */}
        <a href="/" className="return-link">
  ← Return to User Login
</a>

        <p className="secure-text">🔒 Secure Administrator Access</p>
      </div>
    </div>
  );
};

export default AdminLoginPage;
