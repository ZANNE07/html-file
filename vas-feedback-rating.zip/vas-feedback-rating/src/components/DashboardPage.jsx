import React from "react";
import "./../styles/DashboardPage.css";

const DashboardPage = () => {
  const services = [
    {
      title: "Premium Caller Tunes",
      desc: "Set your favorite songs as caller tunes. Choose from thousands of latest hits and classics.",
      reviews: 432,
      rating: 4,
      category: "Featured Services",
      icon: "🎵",
    },
    {
      title: "Unlimited Data Pack",
      desc: "Enjoy unlimited high-speed data with no throttling. Stream, download, and browse without limits.",
      reviews: 1245,
      rating: 5,
      category: "Featured Services",
      icon: "📶",
    },
    {
      title: "Premium Video Streaming",
      desc: "Access to premium movies, TV shows and exclusive content. Watch in HD quality on any device.",
      reviews: 876,
      rating: 4,
      category: "Featured Services",
      icon: "🎬",
    },
    {
      title: "Mobile Gaming Pass",
      desc: "Access 100+ premium mobile games without ads or in-app purchases. New games added monthly.",
      reviews: 328,
      rating: 4,
      category: "Entertainment",
      icon: "🎮",
    },
    {
      title: "Music Streaming Plus",
      desc: "Stream millions of songs ad-free, create playlists and download for offline listening.",
      reviews: 952,
      rating: 5,
      category: "Entertainment",
      icon: "🎧",
    },
    {
      title: "E-Book Library",
      desc: "Access thousands of e-books and audiobooks. New titles added weekly from bestselling authors.",
      reviews: 512,
      rating: 4,
      category: "Entertainment",
      icon: "📚",
    },
    {
      title: "Cloud Storage Pro",
      desc: "50GB secure cloud storage for your photos, videos and documents with automatic backup.",
      reviews: 687,
      rating: 4,
      category: "Utility Services",
      icon: "☁️",
    },
    {
      title: "Mobile Security Suite",
      desc: "Complete protection against viruses, malware and identity theft. Includes VPN and safe browsing.",
      reviews: 423,
      rating: 5,
      category: "Utility Services",
      icon: "🛡️",
    },
    {
      title: "International SMS Pack",
      desc: "Send SMS to any country at reduced rates. Includes 100 international SMS per month.",
      reviews: 215,
      rating: 3,
      category: "Utility Services",
      icon: "✉️",
    },
  ];

  return (
    <div className="dashboard">
      {/* Navbar */}
      <header className="navbar">
        <h2>VAS Feedback & Ratings</h2>
        <nav>
          <a href="#">Dashboard</a>
          <a href="#">Services</a>
          <a href="#">My Reviews</a>
          <a href="#">Analytics</a>
          <a href="#">Help</a>
        </nav>
        <div className="profile">
          <span>John Doe</span>
          <div className="avatar">JD</div>
        </div>
      </header>

      {/* Search & Filters */}
      <div className="search-bar">
        <input type="text" placeholder="Search for services..." />
        <button>🔍</button>
      </div>
      <div className="filters">
        <button className="active">All Services</button>
        <button>Caller Tunes</button>
        <button>Data Plans</button>
        <button>Entertainment</button>
        <button>Gaming</button>
        <button>Education</button>
        <button>Financial</button>
        <button>Health & Fitness</button>
      </div>

      {/* Service Sections */}
      <div className="services-section">
        <h3>Featured Services</h3>
        <div className="card-grid">
          {services
            .filter((s) => s.category === "Featured Services")
            .map((service, idx) => (
              <div key={idx} className="card">
                <div className="icon">{service.icon}</div>
                <h4>{service.title}</h4>
                <p>{service.desc}</p>
                <p className="rating">
                  ⭐⭐⭐⭐⭐ ({service.reviews} reviews)
                </p>
                <button className="btn">Rate & Review</button>
              </div>
            ))}
        </div>
      </div>

      <div className="services-section">
        <h3>Entertainment</h3>
        <div className="card-grid">
          {services
            .filter((s) => s.category === "Entertainment")
            .map((service, idx) => (
              <div key={idx} className="card">
                <div className="icon">{service.icon}</div>
                <h4>{service.title}</h4>
                <p>{service.desc}</p>
                <p className="rating">
                  ⭐⭐⭐⭐⭐ ({service.reviews} reviews)
                </p>
                <button className="btn">Rate & Review</button>
              </div>
            ))}
        </div>
      </div>

      <div className="services-section">
        <h3>Utility Services</h3>
        <div className="card-grid">
          {services
            .filter((s) => s.category === "Utility Services")
            .map((service, idx) => (
              <div key={idx} className="card">
                <div className="icon">{service.icon}</div>
                <h4>{service.title}</h4>
                <p>{service.desc}</p>
                <p className="rating">
                  ⭐⭐⭐⭐⭐ ({service.reviews} reviews)
                </p>
                <button className="btn">Rate & Review</button>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
