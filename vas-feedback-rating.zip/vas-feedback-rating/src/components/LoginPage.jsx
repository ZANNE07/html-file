import React from "react";
import { useNavigate } from "react-router-dom";
import "./../styles/LoginPage.css";

const LoginPage = () => {
  const navigate = useNavigate();

const handleLogin = (e) => {
  e.preventDefault();
  const email = e.target[0].value;
  const password = e.target[1].value;

  if (email === "user@example.com" && password === "password123") {
    navigate("/dashboard");
  } else {
    alert("Invalid login credentials!");
  }
};


  return (
    <div className="login-container">
      {/* Left Panel */}
      <div className="left-panel">
        <h2 className="logo">VAS Rating</h2>
        <h1>Welcome Back!</h1>
        <p>
          Access your VAS Feedback & Rating dashboard to manage your service
          ratings, collect customer feedback, and improve your business
          performance.
        </p>
        <ul>
          <li>📋 Collect valuable customer feedback</li>
          <li>📊 Analyze service performance metrics</li>
          <li>🎧 Improve customer satisfaction</li>
        </ul>
      </div>

      {/* Right Panel */}
      <div className="right-panel">
        <h2>Sign In to Your Account</h2>
        <form onSubmit={handleLogin}>
          <label>Email Address</label>
          <input type="email" placeholder="Enter your email" />

          <label>Password</label>
          <input type="password" placeholder="Enter your password" />

          <div className="form-options">
            <label>
              <input type="checkbox" /> Remember me
            </label>
            <a href="#">Forgot Password?</a>
          </div>

          <button type="submit" className="btn">
            Sign In
          </button>
        </form>

        <p className="register">
          Don’t have an account? <a href="#">Register Now</a>
        </p>

        <p style={{ textAlign: "center", marginTop: "10px" }}>
          <a href="/admin" style={{ color: "#007bff", textDecoration: "none" }}>
            Login as Admin →
          </a>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
